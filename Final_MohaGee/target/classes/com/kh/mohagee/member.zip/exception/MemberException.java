package com.kh.mohagee.member.exception;

public class MemberException extends RuntimeException {
	
	public MemberException() {
		super();
	}
	
	public MemberException(String message) {
		super(message);
	}
	
}
